const storageName = "SavedData";
const EmptyQuestion = "{\"Questions\":[{\"Question\":\"New Question\",\"Explanation\":\"\",\"Image\":\"\",\"isToF\":false,\"ToFAnswer\":false,\"Answers\":[]}]}";

const fileInput = document.getElementById("dragdrop");
const loadButton = document.getElementById("load-button");
const questionInput = document.getElementById("question-input");
const imageInput = document.getElementById("image-input");
const multiInput = document.querySelectorAll(".multi-input");
const multiCheck = document.querySelectorAll(".multi-check");

const questionList = document.querySelector(".question-list");
const editParent = document.querySelector(".edit-parent");

const typeToggle = document.querySelector(".type-toggle");
const multipleChoiceSection = document.querySelector(".multipe-choice-answers");
const tofSection = document.querySelector(".tof-answer");
const tofToggle = document.querySelector(".tof-toggle");

const saveBtn = document.getElementById('saveBtn');


let explanationInput;

let myObj, SelectedQuestion, CurrentSelectedElement = null;

HideCards();
HideFileInput();

window.onload = () => {
  explanationInput = tinymce.get("explanation-input");

  if (localStorage.getItem(storageName) !== null) {
    myObj = JSON.parse(localStorage.getItem(storageName));

    if (myObj === null || myObj === undefined || myObj.Questions.length <= 0) {
      ShowFileInput();
      return;
    }

    ShowCards();
    UpdateList(false);
    questionList.firstChild.onclick();
  } else {
    ShowFileInput();
  }
};

document.addEventListener("keydown", function (e) {
  if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
    e.preventDefault();
    UpdateQuestion();
  }
}, false);

tinymce.init({
  selector: "textarea.rich-text",
  extended_valid_elements: "b/strong,i/em",
  invalid_elements: "div",
  force_br_newlines: true,
  force_p_newlines: false,
  forced_root_block: "",
  menubar: false,
  statusbar: false,
  toolbar: "save | undo redo | bold italic removeformat | fullscreen",
  plugins: "fullscreen, save",
  save_onsavecallback: function () {
    UpdateQuestion();
  },
  save_enablewhendirty: false,
  setup: function (ed) {
    ed.on('change', () => {
      UpdateQuestion();
    });
  }
});

function CreateNew() {
  myObj = JSON.parse(EmptyQuestion);

  UpdateList();
  questionList.firstChild.onclick();
}

function LoadPreviousData() {
  UpdateList();
  questionList.firstChild.onclick();
}

function LoadFile() {
  let input, file, fr;

  if (typeof window.FileReader !== "function") {
    alert("The file API isn't supported on this browser yet.");
    return;
  }

  input = document.getElementById("fileinput");
  if (!input.files) {
    alert("This browser doesn't seem to support the `files` property of file inputs.");
  } else if (!input.files[0]) {
    alert("Please select a file before clicking 'Load'");
  } else {
    file = input.files[0];
    fr = new FileReader();
    fr.onload = ParseFile;
    fr.readAsText(file);
    input.value = null;
  }
}

function ParseFile(e) {
  let lines = e.target.result;
  myObj = JSON.parse(lines);
  UpdateList();

  questionList.firstChild.onclick();
}

function UpdateList(save = true) {
  if (save)
    SaveToLocalStorage();

  while (questionList.firstChild)
    questionList.removeChild(questionList.firstChild);

  questionList.innerHTML = myObj.Questions.map((item, index) => {
    return `<p class="center-text" index=${index} onclick="SelectQuestion(this);">${(index + 1) + ". " + item.Question}<i class="icon-cancel delete" onclick="DeleteQuestion(this);"></i></p>`;
  }).join('');
}

function AddNewQuestion() {
  myObj.Questions.push({
    Question: "New Question",
    Explanation: "",
    Image: "",
    isToF: false,
    ToFAnswer: false,
    Answers: []
  });

  UpdateList();

  questionList.scrollTop = questionList.scrollHeight;
  questionList.lastChild.onclick();
}

function UpdateQuestion() {
  if (SelectedQuestion == null)
    return;

  let AnswerObj = [];

  for (x = 0; x < multiInput.length; x++) {
    if (multiInput[x].value.length <= 0)
      continue;

    AnswerObj.push({
      Text: multiInput[x].value,
      Correct: multiCheck[x].checked.toString()
    });
  }

  myObj.Questions[SelectedQuestion] = {
    Question: questionInput.value,
    Explanation: ConvertFromHTML(explanationInput.getContent(), true),
    Image: imageInput.value,
    isToF: typeToggle.classList.contains("tof"),
    ToFAnswer: !typeToggle.classList.contains("tof") ? false : tofToggle.classList.contains("true"),
    Answers: AnswerObj
  };

  questionList.childNodes[SelectedQuestion].firstChild.data = (SelectedQuestion + 1) + ". " + questionInput.value;

  iqwerty.toast.Toast('✔ Saved');

  SaveToLocalStorage();
}

function SelectQuestion(elt) {
  if (CurrentSelectedElement !== null)
    CurrentSelectedElement.classList.remove("selected");

  ShowCards();

  SelectedQuestion = Number(elt.attributes.index.nodeValue);
  CurrentSelectedElement = elt;

  CurrentSelectedElement.classList.add("selected");

  questionInput.value = myObj.Questions[SelectedQuestion].Question;
  explanationInput.setContent(ConvertToHTML(myObj.Questions[SelectedQuestion].Explanation));
  imageInput.value = myObj.Questions[SelectedQuestion].Image;

  multiInput.forEach((item) => {
    item.value = "";
  });

  multiCheck.forEach((item) => {
    item.checked = false;
  });

  if (myObj.Questions[SelectedQuestion].Answers.length > 0) {
    myObj.Questions[SelectedQuestion].Answers.forEach((item, index) => {
      multiInput[index].value = item.Text;
      multiCheck[index].checked = (item.Correct === "true");
    });
  }

  AdaptUI();
}

function ChangeQuestionType() {
  myObj.Questions[SelectedQuestion].isToF = !myObj.Questions[SelectedQuestion].isToF;
  AdaptUI();
  UpdateQuestion();
}

function ChangeToFAnswer() {
  myObj.Questions[SelectedQuestion].ToFAnswer = !myObj.Questions[SelectedQuestion].ToFAnswer;
  AdaptUI();
  UpdateQuestion();
}

function AdaptUI() {
  if (myObj.Questions[SelectedQuestion].isToF) {
    typeToggle.textContent = "True or False Question";

    typeToggle.classList.add("tof");
    multipleChoiceSection.classList.add("hidden");
    tofSection.classList.remove("hidden");

    if (myObj.Questions[SelectedQuestion].ToFAnswer) {
      tofToggle.textContent = "TRUE";
      tofToggle.classList.add("true");
    } else {
      tofToggle.textContent = "FALSE";
      tofToggle.classList.remove("true");
    }

  } else {
    typeToggle.textContent = "Multiple Choice Question";

    typeToggle.classList.remove("tof");
    multipleChoiceSection.classList.remove("hidden");
    tofSection.classList.add("hidden");
  }
}

function DeleteQuestion(elt) {
  swal({
      title: "Delete Question?",
      text: "Once deleted, you cannot undo this!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {

        myObj.Questions.splice(SelectedQuestion, 1);

        iqwerty.toast.Toast("✔ Question Deleted");

        UpdateList();

        if (questionList.childNodes.length == 0)
          ShowFileInput();
        else if (questionList.childNodes[SelectedQuestion] !== undefined)
          questionList.childNodes[SelectedQuestion].onclick();
        else
          questionList.childNodes[SelectedQuestion - 1].onclick();
      }
    });
}

function DeleteAllQuestions() {
  swal({
      title: "Delete ALL Questions?",
      text: "Once deleted, you cannot undo this!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {

        myObj = null;
        SaveToLocalStorage();

        iqwerty.toast.Toast("✔ Questions Deleted");

        ShowFileInput();
      }
    });
}

function SaveToLocalStorage() {
  localStorage.setItem(storageName, JSON.stringify(myObj));
}

function SaveJSON() {
  let saveObj = [];

  myObj.Questions.forEach((item, index) => {
    saveObj.push(item);

    if (item.isToF) {
      saveObj[index].Answers = [];
    }
  });

  let fileName = "QuizApp.json";
  let dataStr = "data:application/json;charset=utf-8," + encodeURIComponent(JSON.stringify({
    Questions: saveObj
  }));
  saveBtn.setAttribute("href", dataStr);
  saveBtn.setAttribute("download", fileName);
}

function ConvertFromHTML(str, allowBreaks = true) {
  if (allowBreaks)
    return str.replace(/(&nbsp;)*/g, "").replace(/(<p>)*/g, "").replace(/<(\/)?p[^>]*>/g, "").replace(/<br[^>]*>/gi, "\n").trim();
  else
    return str.replace(/(&nbsp;)*/g, "").replace(/(<p>)*/g, "").replace(/<(\/)?p[^>]*>/g, "").replace(/<br[^>]*>/gi, " ").trim();
}

function ConvertToHTML(str) {
  return str.replace(/\n/g, "<br/>");
}

function ShowCards() {
  editParent.classList.remove("hidden");

  CardsHidden = false;

  HideFileInput();
}

function ShowFileInput() {
  fileInput.style.display = "block";

  if (myObj === null || myObj === undefined || myObj.Questions.length <= 0)
    loadButton.style.display = "none";
  else
    loadButton.style.display = "inline-block";

  HideCards();
}

function HideCards() {
  editParent.classList.add("hidden");
  CardsHidden = true;
}

function HideFileInput() {
  fileInput.style.display = "none";
}